-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: calzados_pos
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cajas`
--

DROP TABLE IF EXISTS `cajas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cajas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cajero_id` bigint NOT NULL,
  `apertura` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cierre` timestamp NULL DEFAULT NULL,
  `monto_inicial` decimal(12,2) NOT NULL,
  `total_efectivo` decimal(12,2) DEFAULT '0.00',
  `total_yape` decimal(12,2) DEFAULT '0.00',
  `total_tarjeta` decimal(12,2) DEFAULT '0.00',
  `monto_final_esperado` decimal(12,2) DEFAULT '0.00',
  `monto_final_real` decimal(12,2) DEFAULT '0.00',
  `diferencia` decimal(12,2) DEFAULT '0.00',
  `estado` varchar(20) NOT NULL DEFAULT 'ABIERTA',
  PRIMARY KEY (`id`),
  KEY `idx_cajas_cajero_estado` (`cajero_id`,`estado`),
  CONSTRAINT `fk_caja_usuario` FOREIGN KEY (`cajero_id`) REFERENCES `users` (`id`),
  CONSTRAINT `chk_estado_caja` CHECK ((`estado` in (_utf8mb4'ABIERTA',_utf8mb4'CERRADA')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cajas`
--

LOCK TABLES `cajas` WRITE;
/*!40000 ALTER TABLE `cajas` DISABLE KEYS */;
/*!40000 ALTER TABLE `cajas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `dni` varchar(8) DEFAULT NULL,
  `ruc` varchar(11) DEFAULT NULL,
  `razon_social` varchar(200) DEFAULT NULL,
  `numero_telefono` varchar(15) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `direccion` varchar(250) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dni` (`dni`),
  UNIQUE KEY `ruc` (`ruc`),
  KEY `idx_clientes_dni` (`dni`),
  KEY `idx_clientes_ruc` (`ruc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comprobantes`
--

DROP TABLE IF EXISTS `comprobantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comprobantes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `serie` varchar(20) NOT NULL,
  `tipo` varchar(10) NOT NULL,
  `numero` int NOT NULL,
  `venta_id` bigint NOT NULL,
  `cliente_id` bigint DEFAULT NULL,
  `cliente_nombre` varchar(200) DEFAULT NULL,
  `cliente_dni` varchar(8) DEFAULT NULL,
  `cliente_ruc` varchar(11) DEFAULT NULL,
  `cliente_razon_social` varchar(200) DEFAULT NULL,
  `cliente_direccion` varchar(250) DEFAULT NULL,
  `cliente_email` varchar(150) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `descuento` decimal(12,2) DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL,
  `igv` decimal(12,2) DEFAULT NULL,
  `base_imponible` decimal(12,2) DEFAULT NULL,
  `fecha_emision` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `serie` (`serie`),
  UNIQUE KEY `venta_id` (`venta_id`),
  KEY `idx_comprobantes_fecha` (`fecha_emision`),
  KEY `idx_comprobantes_tipo` (`tipo`),
  KEY `idx_comprobantes_cliente` (`cliente_id`),
  CONSTRAINT `fk_comprobante_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_comprobante_venta` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`id`),
  CONSTRAINT `chk_tipo_comprobante` CHECK ((`tipo` in (_utf8mb4'BOLETA',_utf8mb4'FACTURA')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comprobantes`
--

LOCK TABLES `comprobantes` WRITE;
/*!40000 ALTER TABLE `comprobantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `comprobantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_solicitud_compra`
--

DROP TABLE IF EXISTS `detalle_solicitud_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_solicitud_compra` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `solicitud_compra_id` bigint NOT NULL,
  `producto_id` bigint NOT NULL,
  `variante_id` bigint NOT NULL,
  `cantidad_solicitada` int NOT NULL,
  `cantidad_recibida` int NOT NULL DEFAULT '0',
  `precio_unitario` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_det_solicitud_producto` (`producto_id`),
  KEY `idx_detalle_solicitud_compra_id` (`solicitud_compra_id`),
  KEY `idx_detalle_solicitud_variante_id` (`variante_id`),
  CONSTRAINT `fk_det_solicitud_compra` FOREIGN KEY (`solicitud_compra_id`) REFERENCES `solicitud_compra` (`id`),
  CONSTRAINT `fk_det_solicitud_producto` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`),
  CONSTRAINT `fk_det_solicitud_variante` FOREIGN KEY (`variante_id`) REFERENCES `variante` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_solicitud_compra`
--

LOCK TABLES `detalle_solicitud_compra` WRITE;
/*!40000 ALTER TABLE `detalle_solicitud_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_solicitud_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_venta`
--

DROP TABLE IF EXISTS `detalle_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_venta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `venta_id` bigint NOT NULL,
  `variante_id` bigint NOT NULL,
  `cantidad` int NOT NULL,
  `precio_unitario` decimal(12,2) NOT NULL,
  `costo_unitario` decimal(12,2) NOT NULL DEFAULT '0.00',
  `descuento_item` decimal(12,2) DEFAULT '0.00',
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_detalle_venta` (`venta_id`),
  KEY `idx_detalle_variante` (`variante_id`),
  CONSTRAINT `fk_detalle_variante` FOREIGN KEY (`variante_id`) REFERENCES `variante` (`id`),
  CONSTRAINT `fk_detalle_venta` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_venta`
--

LOCK TABLES `detalle_venta` WRITE;
/*!40000 ALTER TABLE `detalle_venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gasto`
--

DROP TABLE IF EXISTS `gasto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gasto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tipo` varchar(30) NOT NULL,
  `concepto` varchar(180) NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `fecha_gasto` date NOT NULL,
  `descripcion` text,
  `usuario_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_gasto_usuario` (`usuario_id`),
  KEY `idx_gasto_fecha` (`fecha_gasto`),
  KEY `idx_gasto_tipo_fecha` (`tipo`,`fecha_gasto`),
  CONSTRAINT `fk_gasto_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `users` (`id`),
  CONSTRAINT `chk_tipo_gasto` CHECK ((`tipo` in (_utf8mb4'CREDITO_PROVEEDOR',_utf8mb4'LUZ',_utf8mb4'INTERNET',_utf8mb4'ALQUILER',_utf8mb4'PLANILLA',_utf8mb4'TRANSPORTE',_utf8mb4'OTRO')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gasto`
--

LOCK TABLES `gasto` WRITE;
/*!40000 ALTER TABLE `gasto` DISABLE KEYS */;
/*!40000 ALTER TABLE `gasto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marca`
--

DROP TABLE IF EXISTS `marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marca` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marca`
--

LOCK TABLES `marca` WRITE;
/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` VALUES (1,'Aldama',1);
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `marca_id` bigint DEFAULT NULL,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_producto_marca` (`marca_id`),
  CONSTRAINT `fk_producto_marca` FOREIGN KEY (`marca_id`) REFERENCES `marca` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,1,'CHAROL NEGRO','LASO NEGRO',1),(2,1,'CHEMI NEGRO','LASO NEGRO',1),(3,1,'CHELBY NEGRO','BRILLOSO,LASO DE TELA NEGRO',1),(4,1,'CHELBY NEGRO','BRILLOSO,LASO DE TELA NEGRO',1),(5,1,'CHAROL BLANCO','LASO CHAROL BLANCO',1),(6,1,'CHEMI BLANCO','5 FLORES PEQUEÑAS BLANCAS DE COSTADO',1),(7,1,'CHEMI NEGRO','LASO NEGRO BRILLOSO',1),(8,1,'CHEMI NEGRO','LASO NEGRO',1),(9,1,'CHEMI BLANCO','5 FLORES DE COSTADO',1),(10,1,'CHEMI BLANCO','5 FLORES DE COSTADO',1),(11,1,'CHEMI BLANCO','3 FLORES BLANCAS',1),(12,1,'CHAROL NEGRO','LASO DE CHAROL',1),(13,1,'CHELBY NEGRO','LASO DE TELA',1),(14,1,'CHAROL ROJO','LASO CHAROL ROJO',1),(15,1,'SATIN VERDE','LASO DE SATIN VERDE',1),(16,1,'CHEMI BLANCO','LASO BLANCO',1),(17,1,'CHEMI FUCSIA','3 FLORES FUCSIA',1),(18,1,'CHELBY NEGRO','LASO DE TELA NEGRA',1),(19,1,'CUERITO COBRE','LASO COLOR COBRE',1),(20,1,'CHEMI ROSADO','LASO ROSADO,PUNTA ESCARCHADO',1),(21,1,'ANIMAL PRINTS','LASO DE ANIMAL PRINTS',1),(22,1,'CHEMI NEGRO','LASO NEGRO BRILLOSO',1),(23,1,'SATIN ORO','LASO DE SATIN ORO',1),(24,1,'CHAROL NEGRO','LASO NEGRO Y DORADO',1),(25,1,'CHEMI BEIGE','LASO BEIGE Y PUNTA ESCARCHADO',1),(26,1,'CHEMI BEIGE','LASO BEIGE Y PUNTA ESCARCHADO',1),(27,1,'CHEMI BEIGE','LASO BEIGE Y PUNTA ESCARCHADA',1),(28,1,'CHANEL NEGRO','LASO NEGRO',1),(29,1,'CHAROL YOGURT','LASO COLOR YOGURT',1),(30,1,'CHAROL NEGRO','LASO NEGRO',1),(31,1,'CHAROL BLANCO','LASO BLANCO',1),(32,1,'SATIN AZUL','LASO DE SATIN',1),(33,1,'DUBLIN PLATA','LASO DELGADO DE PLATA',1),(34,1,'SATIN VINO','LASO DE COLOR VINO',1),(35,1,'SATIN AZUL','LASO DE SATIN AZUL',1),(36,1,'SATIN VINO','LASO DE COLOR VINO',1),(37,1,'CHAMAT ORO','LASO DE ORO',1),(38,1,'SATIN VINO','LASO DE COLOR VINO',1),(39,1,'SATIN AZUL','LASO DE SATIN',1),(40,1,'SATIN AZUL','LASO DE SATIN AZUL',1),(41,1,'SATIN VINO','LASO DE SATIN VINO',1),(42,1,'CHAMAT ORO','LASO DE ORO',1),(43,1,'CUERITO PLATA','LASO DE PLATA',1),(44,1,'SATIN AZUL','LASO DE COLOR AZUL',1),(45,1,'CUERITO DE PLATA','LASO DE COLOR PLATA',1),(46,1,'DUBLIN PLATA','LASO DE COLOR PLATA',1),(47,1,'CUERITO COBRE','LASO DE COLOR COBRE',1),(48,1,'SUEDE ROSA BB','LASO ROSA BB',1),(49,1,'SUEDE NEGRO','LASO DE SUEDE NEGRO',1),(50,1,'SUEDE PALO ROSA','LASO DE COLOR PALO ROSA',1),(51,1,'SUEDE MARRON','LASO DE COLOR MARRON',1),(52,1,'CHEMI NUDE','LASO COLOR NUDE',1),(53,1,'SUEDE MARRON','LASO COLOR MARRON',1),(54,1,'DUBLAS PLATA','LASO DE COLOR PLATA',1),(55,1,'SUEDE MARRON','LASO MARRON',1),(56,1,'CHAMIT ROSADO','LASO COLOR ROSADO',1),(57,1,'SUEDE AZUL','LASO DE COLOR AZUL',1),(58,1,'SUEDE MARRON','LASO MARRON',1),(59,1,'SUEDE AZUL','LASO DE COLOR AZUL',1),(60,1,'SUEDE AZUL','LASO DE COLOR AZUL',1),(61,1,'GLITTER PLATA','ESCARCHADO COLOR PLATA ',1),(62,1,'SATIN VERDE ','LASO EN LA CORREA',1),(63,1,'CHAROL BLANCO','LASO COLOR BLANCO',1),(64,1,'CHAMAT MARRON','LASO DE COLOR MARRON',1),(65,1,'CHAMAT MARRON','LASO DE COLOR MARRON',1),(66,1,'CHAROL ROJO','LASO ROJO',1),(67,1,'CHAROL CELESTE','LASO CELESTE',1),(68,1,'CHAROL AZUL','LASO DE TELA',1),(69,1,'CHAROL NUDE ROSA','LASO DE COLOR NUDE ROSA',1),(70,1,'CHEMI FUCSIA','LASO DE COLOR FUCSIA',1),(71,1,'CHAROL NUDE ROSA','LASO DE COLOR NUDE ROSA',1),(72,1,'CHEMI NEGRO','3 FLORES DE COLOR NEGRO',1),(73,1,'CHAROL NEGRO','LASO DE TELA',1),(74,1,'DUBLAS PLATA','LASO DE LATA',1),(75,1,'DUBLAS PLATA','LASO DE PLATA',1),(76,1,'CHAROL ROJO','LASOS DE TELA COLOR ROJO',1),(77,1,'CHAROL  BLANCO','LASO BLANCO',1),(78,1,'DUBLIN ORO','LASO DE ORO',1),(79,1,'CHEMI ROSADO','LASO ROSADO Y PUNTA ESCARCHADO',1),(80,1,'CHEMI AZUL','LASO AZUL Y PUNTA ESCARCHADO',1),(81,1,'CHEMI AZUL','LASO AZUL Y PUNTA ESCARCHADA',1),(82,1,'CHEMI FUCSIA','LASO FUCSIA Y PUNTA ESCARCHADO',1),(83,1,'CHEMI AZUL','LASO AZUL Y PUNTA ESCARCHADA',1),(84,1,'CHEMI FUCSIA ','LASO FUCSIA Y PUNTA ESCARCHADO',1),(85,1,'CHEMI FUCSIA','LASO ROSADO Y PUNTA ESCARCHADO',1),(86,1,'SUEDE LILA','LASO LILA',1),(87,1,'CHAMAT MARRON','LASO MARRON',1),(88,1,'CHAMAT PLATA','LASO PLATA',1),(89,1,'CHAMAT ROSADO','LASO ESCARCHADO',1),(90,1,'CHEMI BLANCO','LASO BLANCO',1),(91,1,'CHEMI ROJO','LASO ROJO',1),(92,1,'CHEMI MELON','LASO MELON',1),(93,1,'HAIRLINE PLATA','LASO PLATA',1),(94,1,'HAIRLINE PLATA','LASO PLATA',1),(95,1,'HAIRLINE PLATA','LASO PLOMO',1),(96,1,'CHAMAT ROJO','LASO ROJO',1),(97,1,'CHEMI ROSADO','LASO ROSADO',1),(98,1,'CHAMIT ROSADO','LASO ROSADO',1),(99,1,'CHAMAT NEGRO','LASO NEGRO',1),(100,1,'CHEMI BLANCO','3 FLORES DE BLANCO',1),(101,1,'SATIN VINO','LASO DE TELA VINO',1),(102,1,'METAL ROJO','SIN DISEÑO',1),(103,1,'CHAROL CELESTE','LASO CELESTE',1),(104,1,'CHAROL AZUL','LASO DE TELA AZUL',1),(105,1,'SALIN VERDE','LASO VERDE',1),(106,1,'CHEMI FUCSIA ','3 FLORES FUCSIA',1),(107,1,'CHAROL ROJO','LASO ROJO',1),(108,1,'CHEMI NEGRO','3 ROSAS NEGRAS',1),(109,1,'CHAROL ROJO','LASO DE TELA ROJO',1),(110,1,'CUBICO PERLA','LASO E TELA COLOR PERLA',1),(111,1,'CHAROL NUDE ROSA','LASO NUDE ROSA',1),(112,1,'TAMASOL BLANCO','LASO BLANCO',1),(113,1,'CHAROL ROJO','LASO ROJO',1),(114,1,'SUEDE LILA','LASOS LILA',1),(115,1,'CHEMI MELON','LASO MELON',1),(116,1,'CHEMI ROSADO','LASO ROSADO',1),(117,1,'CHAROL ROJO','LASO ROJO',1),(118,1,'CHAROL ROJO','LASO ROJO',1),(119,1,'CHEMI MELON','LASO DE MELON',1),(120,1,'CHAMAT ROSADO','LASO ROSADO',1),(121,1,'CHEMI ROSADO','LASO ROSADO',1),(122,1,'CHAMAT MARRON','LASO MARRON',1),(123,1,'SUEDE LILA','LASO LILA',1),(124,1,'CHEMI ROSADO','LASO ROSADO',1),(125,1,'CHAROL NEGRO','LASO NEGRO',1),(126,1,'CHAROL BLANCO','LASO BLANCO',1),(127,1,'CHEMI BEIGE','LASO BEIGE, PUNTA ESCARCHADA',1),(128,1,'CHAROL NEGRO','LASO NEGRO',1),(129,1,'CHANELL YOGURT','LASO YOGURT',1),(130,1,'CHAMAT ROSADO','LASO ROSADO',1),(131,1,'CHEMI FUCSIA','LASO FUCSI, PUNTA ESCARCHADA',1),(132,1,'DUBLIN ORO','LASO ORO',1),(133,1,'HAIRLINE PLATA','LASO PLATA',1),(134,1,'CHEMI AZUL','LAZO AZUL Y PUNTA DORADO',1),(135,1,'CHEMI ROSADO','LASO ROSADO Y PUNTA ESCARCHADA',1),(136,1,'CHAROL BLANCO','LASO BLANCO',1),(137,1,'DUBLIN PLATA','LASO PLATA',1),(138,1,'CHELBY NEGRO','LASO NEGRO',1),(139,1,'CHAMAT ROSADO','LASO ROSADO',1),(140,1,'CHAMAT ORO','LASO DORADO',1),(141,1,'CHEMI NEGRO','LASO NEGRO',1),(142,1,'METAL NUDE ROSA','SIN DISEÑO',1),(143,1,'HAIRLINE VERDE','LASO VERDE',1),(144,1,'ANIMAL PRINCS','LASITO',1),(145,1,'CHAROL NUDE','LASO CON ESCARCHA',1),(146,1,'CHAROL YOGURT','LASO DE COLOR YOGURT',1),(147,1,'CHAMAT ROJO','LASO ROJO',1),(148,1,'METAL ROSADO','LASO ROSADO',1),(149,1,'CHAMAT PLATA','LASO PLATA',1);
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedor` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `ruc` varchar(11) NOT NULL,
  `contacto` varchar(100) NOT NULL,
  `numero_telefono` varchar(15) NOT NULL,
  `email` varchar(150) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `dias_credito` int NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ruc` (`ruc`),
  KEY `idx_proveedor_nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitud_compra`
--

DROP TABLE IF EXISTS `solicitud_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitud_compra` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) NOT NULL,
  `proveedor_id` bigint NOT NULL,
  `usuario_id` bigint NOT NULL,
  `condicion_pago` varchar(20) NOT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `fecha_solicitud` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` decimal(12,2) NOT NULL,
  `pagado` tinyint(1) NOT NULL DEFAULT '0',
  `estado` varchar(30) NOT NULL DEFAULT 'PENDIENTE_RECEPCION',
  `observacion` text,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `fk_solicitud_usuario` (`usuario_id`),
  KEY `idx_solicitud_proveedor_estado` (`proveedor_id`,`estado`),
  KEY `idx_solicitud_fecha` (`fecha_solicitud`),
  KEY `idx_solicitud_pagado` (`pagado`),
  CONSTRAINT `fk_solicitud_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `fk_solicitud_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `users` (`id`),
  CONSTRAINT `chk_solicitud_condicion_pago` CHECK ((`condicion_pago` in (_utf8mb4'CONTADO',_utf8mb4'CREDITO'))),
  CONSTRAINT `chk_solicitud_estado` CHECK ((`estado` in (_utf8mb4'PENDIENTE_RECEPCION',_utf8mb4'PARCIAL_RECEPCION',_utf8mb4'RECEPCIONADA',_utf8mb4'ANULADA')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud_compra`
--

LOCK TABLES `solicitud_compra` WRITE;
/*!40000 ALTER TABLE `solicitud_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `solicitud_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` varchar(20) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  CONSTRAINT `chk_rol` CHECK ((`rol` in (_latin1'ADMIN',_latin1'CAJERO')))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrador','admin@aldama.pos','$2a$10$0UcVhXEOuo/7AHrttVdNpOR.gSeTgCIO1vcQblev./MqtFWR49prW','ADMIN',1,'2026-06-22 16:25:05'),(2,'sara','sara@gmail.com','$2a$10$bOdANbgtPs8XkH1oniYFCuYUg8OmZqOxtKDpNFtz2j50NZWdSGEzq','CAJERO',1,'2026-06-23 05:07:35');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variante`
--

DROP TABLE IF EXISTS `variante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variante` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `producto_id` bigint NOT NULL,
  `color` varchar(50) DEFAULT NULL,
  `talla` varchar(20) DEFAULT NULL,
  `ubicacion` varchar(20) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `codigo_barras` varchar(100) DEFAULT NULL,
  `precio_compra` decimal(12,2) NOT NULL,
  `porcentaje_ganancia` decimal(5,2) DEFAULT NULL,
  `precio_venta` decimal(12,2) NOT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `stock_minimo` int DEFAULT '5',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_ingreso` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  UNIQUE KEY `codigo_barras` (`codigo_barras`),
  KEY `idx_variante_producto` (`producto_id`),
  KEY `idx_variante_codbarras` (`codigo_barras`),
  CONSTRAINT `fk_variante_producto` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variante`
--

LOCK TABLES `variante` WRITE;
/*!40000 ALTER TABLE `variante` DISABLE KEYS */;
INSERT INTO `variante` VALUES (1,1,'NEGRO','21','A1','SK2','0000001',25.00,50.00,37.50,1,1,1,NULL),(2,2,'NEGRO','20','A1','SK1','0000002',22.00,50.00,33.00,1,1,1,NULL),(3,3,'NEGRO','20','A1','SK3','0000003',22.00,50.00,33.00,1,1,1,NULL),(4,4,'NEGRO','20','A1','SK4','0000004',22.00,50.00,33.00,1,1,1,NULL),(5,5,'BLANCO','19','A1','SK5','0000005',22.00,50.00,33.00,1,1,1,NULL),(6,6,'BLANCO','18','A1','SK6','0000006',22.00,50.00,33.00,1,1,1,NULL),(7,7,'NEGRO','20','A1','SK7','0000007',22.00,50.00,33.00,1,1,1,NULL),(8,8,'NEGRO','19','A1','SK8','0000008',22.00,50.00,33.00,1,1,1,NULL),(9,9,'BLANCO','20','A1','SKU9','0000009',22.00,50.00,33.00,1,1,1,NULL),(10,10,'BLANCO','19','A1','S1','0000010',22.00,50.00,33.00,1,1,1,NULL),(11,11,'BLANCO','19','A1','S2','0000011',22.00,50.00,33.00,1,1,1,NULL),(12,12,'NEGRO','20','A1','S5','0000012',22.00,50.00,33.00,1,1,1,NULL),(13,13,'NEGRO','19','A1','AS','0000013',22.00,50.00,33.00,1,1,1,NULL),(14,14,'ROJO','19','A1','W3','0000014',22.00,50.00,33.00,1,1,1,NULL),(15,15,'VERDE','19','A1','V1','0000015',22.00,50.00,33.00,1,0,1,NULL),(16,16,'BLANCO','18','A1','B2','0000016',22.00,50.00,33.00,1,0,1,NULL),(17,17,'FUCSIA','20','A1','F1','0000017',22.00,50.00,33.00,1,0,1,NULL),(18,18,'NEGRO','19','A1','N1','0000018',22.00,50.00,33.00,1,1,1,NULL),(19,19,'COBRE','20','A1','C2','0000019',22.00,50.00,33.00,1,1,1,NULL),(20,20,'ROSADO','19','A1','R1','0000020',22.00,50.00,33.00,1,1,1,NULL),(21,21,'ANIMAL PRINTS','19','A1','AP1','0000021',22.00,50.00,33.00,1,0,1,NULL),(22,22,'NEGRO','17','A1','N3','0000022',22.00,50.00,33.00,1,0,1,NULL),(23,23,'ORO','20','A1','O1','0000023',22.00,50.00,33.00,1,1,1,NULL),(24,24,'NEGRO','19','A1','N2','0000024',22.00,50.00,33.00,1,1,1,NULL),(25,25,'BEIGE','18','A1','B1','0000025',22.00,50.00,33.00,1,1,1,NULL),(26,26,'BEIGE','19','A1','BB1','0000026',22.00,50.00,33.00,1,1,1,NULL),(27,27,'BEIGE','20','A1','BG1','0000027',22.00,50.00,33.00,1,1,1,NULL),(28,28,'NEGRO','18','A1','NO1','0000028',22.00,50.00,33.00,1,1,1,NULL),(29,29,'ROSADO','18','A1','RSD1','0000029',22.00,50.00,33.00,1,1,1,NULL),(30,30,'NEGRO','20','A1','NRG1','0000030',22.00,50.00,33.00,1,1,1,NULL),(31,31,'BLANCO','18','A1','BN1','0000031',22.00,50.00,33.00,1,1,1,NULL),(32,32,'AZUL','17','A1','ST1','0000032',22.00,50.00,33.00,1,1,1,NULL),(33,33,'PLATA','18','A1','PT1','0000033',22.00,50.00,33.00,1,1,1,NULL),(34,34,'VINO','19','A1','VN1','0000034',22.00,50.00,33.00,1,1,1,NULL),(35,35,'AZUL','19','A1','AL1','0000035',22.00,50.00,33.00,1,1,1,NULL),(36,36,'VINO','20','A1','VNS1','0000036',22.00,50.00,33.00,1,1,1,NULL),(37,37,'ORO','19','A1','ORO1','0000037',22.00,50.00,33.00,1,1,1,NULL),(38,38,'VINO','17','A1','VR1','0000038',22.00,50.00,33.00,1,1,1,NULL),(39,39,'AZUL','18','A1','AV1','0000039',22.00,50.00,33.00,1,1,1,NULL),(40,40,'AZUL','20','A1','STF1','0000040',22.00,50.00,33.00,1,1,1,NULL),(41,41,'VINO','18','A1','Q1','0000041',22.00,50.00,33.00,1,1,1,NULL),(42,42,'ORO','18','A1','TR1','0000042',22.00,50.00,33.00,1,1,1,NULL),(43,43,'PLATA','19','A1','LT1','0000043',22.00,50.00,33.00,1,1,1,NULL),(44,44,'AZUL','19','A1','AFL1','0000044',22.00,50.00,33.00,1,1,1,NULL),(45,45,'PLATA','17','A1','PLT1','0000045',22.00,50.00,33.00,1,1,1,NULL),(46,46,'PLATA','19','A1','SF1','0000046',22.00,50.00,33.00,1,1,1,NULL),(47,47,'COBRE','18','A1','Q','0000047',22.00,50.00,33.00,1,1,1,NULL),(48,48,'ROSA BB','19','A1','RS1','0000048',22.00,50.00,33.00,1,1,1,NULL),(49,49,'NEGRO','18','A1','SD1','0000049',22.00,50.00,33.00,1,1,1,NULL),(50,50,'PALO ROSA','19','A1','A1','0000050',22.00,50.00,33.00,1,1,1,NULL),(51,51,'MARRON','19','A1','MR1','0000051',22.00,50.00,33.00,1,1,1,NULL),(52,52,'NUDE','','A1','ND1','0000052',22.00,50.00,33.00,1,1,1,NULL),(53,53,'MARRON','20','A1','KI1','0000053',22.00,50.00,33.00,1,1,1,NULL),(54,54,'PLATA','20','A1','QFL','0000054',22.00,50.00,33.00,1,1,1,NULL),(55,55,'MARRON','17','A1','W','0000055',22.00,50.00,33.00,1,1,1,NULL),(56,56,'ROSADO','20','A1','RSD','0000056',22.00,50.00,33.00,1,1,1,NULL),(57,57,'AZUL','19','A1','AL','0000057',22.00,50.00,33.00,1,1,1,NULL),(58,58,'MARRON','18','A1','AQ1','0000058',22.00,50.00,33.00,1,1,1,NULL),(59,59,'AZUL','18','A1','ÑP','0000059',22.00,50.00,33.00,1,1,1,NULL),(60,60,'AZUL','20','A1','RQ','0000060',22.00,50.00,33.00,1,1,1,NULL),(61,61,'PLATA','20','A1','ECH','0000061',22.00,50.00,33.00,1,1,1,NULL),(62,62,'VERDE','20','A1','STN','0000062',22.00,50.00,33.00,1,1,1,NULL),(63,63,'BLANCO','18','A1','BLC1','0000063',22.00,50.00,33.00,1,1,1,NULL),(64,64,'MARRON','19','A1','AWQ','0000064',22.00,50.00,33.00,1,1,1,NULL),(65,65,'MARRON','20','A1','QJA','0000065',22.00,50.00,33.00,1,1,1,NULL),(66,66,'ROJO','20','A1','L','0000066',22.00,50.00,33.00,1,1,1,NULL),(67,67,'CELESTE','20','A1','GT','0000067',22.00,50.00,33.00,1,1,1,NULL),(68,68,'AZUL','18','A1','WK','0000068',22.00,50.00,33.00,1,1,1,NULL),(69,69,'NUDE ROSA','20','A1','NU','0000069',22.00,50.00,33.00,1,1,1,NULL),(70,70,'FUCSIA','20','A1','TH','0000070',22.00,50.00,33.00,1,1,1,NULL),(71,71,'NUDE ROSA','18','A1','ND','0000071',22.00,50.00,33.00,1,1,1,NULL),(72,72,'NEGRO','20','A1','FU','0000072',22.00,50.00,33.00,1,1,1,NULL),(73,73,'NEGRO','20','A1','QM','0000073',22.00,50.00,33.00,1,1,1,NULL),(74,74,'PLATA','18','A1','RL','0000074',22.00,50.00,33.00,1,1,1,NULL),(75,75,'PLATA','17','A1','VT','0000075',22.00,50.00,33.00,1,1,1,NULL),(76,76,'ROJO','20','A1','WN','0000076',22.00,50.00,33.00,1,1,1,NULL),(77,77,'BLANCO','19','A1','KWQ','0000077',22.00,50.00,33.00,1,1,1,NULL),(78,78,'ORO','20','A1','NPS','0000078',22.00,50.00,33.00,1,1,1,NULL),(79,79,'ROSADO','18','A1','WBF','0000079',22.00,50.00,33.00,1,1,1,NULL),(80,80,'AZUL','20','A1','PH','0000080',22.00,50.00,33.00,1,1,1,NULL),(81,81,'AZUL','18','A1','PEH','0000081',22.00,50.00,33.00,1,1,1,NULL),(82,82,'FUCSIA','20','A1','HX','0000082',22.00,50.00,33.00,1,1,1,NULL),(83,83,'AZUL','19','A1','WO','0000083',22.00,50.00,33.00,1,1,1,NULL),(84,84,'FUCSIA','19','A1','DOI','0000084',22.00,50.00,33.00,1,1,1,NULL),(85,85,'FUCSIA','18','A1','EHQ','0000085',22.00,50.00,33.00,1,1,1,NULL),(86,86,'LILA','18','A1','GWV','0000086',22.00,50.00,33.00,1,1,1,NULL),(87,87,'MARRON','17','A1','NRP','0000087',22.00,50.00,33.00,1,1,1,NULL),(88,88,'PLATA','17','A1','WÑO','0000088',22.00,50.00,33.00,1,1,1,NULL),(89,89,'ROSADO','20','A1','WMO','0000089',22.00,50.00,33.00,1,1,1,NULL),(90,90,'BLANCO','17','A1','DV','0000090',22.00,50.00,33.00,1,1,1,NULL),(91,91,'ROJO','17','A1','XKL','0000091',22.00,50.00,33.00,1,1,1,NULL),(92,92,'MELON','18','A1','PSA','0000092',22.00,50.00,33.00,1,1,1,NULL),(93,93,'PLATA','18','A1','NL','0000093',22.00,50.00,33.00,1,1,1,NULL),(94,94,'PLATA','19','A1','NWX','0000094',22.00,50.00,33.00,1,1,1,NULL),(95,95,'PLOMO','20','A1','WHH','0000095',22.00,50.00,33.00,1,1,1,NULL),(96,96,'ROJO','17','A1','DTG','0000096',22.00,50.00,33.00,1,1,1,NULL),(97,97,'ROSADO','17','A1','RVVF','0000097',22.00,50.00,33.00,1,1,1,NULL),(98,98,'ROSADO','17','A1','VPW','0000098',22.00,50.00,33.00,1,1,1,NULL),(99,99,'NEGRO','17','A1','THDS','0000099',22.00,50.00,33.00,1,1,1,NULL),(100,100,'BLANCO','17','A1','PNSF','0000100',22.00,50.00,33.00,1,1,1,NULL),(101,101,'VINO','17','A1','PDJ','0000101',22.00,50.00,33.00,1,1,1,NULL),(102,102,'ROJO','17','A1','RXK','0000102',22.00,50.00,33.00,1,1,1,NULL),(103,103,'CELESTE','17','A1','JDOS','0000103',22.00,50.00,33.00,1,1,1,NULL),(104,104,'AZUL','17','A1','PCR','0000104',22.00,50.00,33.00,1,1,1,NULL),(105,105,'VERDE','17','A1','OWB','0000105',22.00,50.00,33.00,1,1,1,NULL),(106,106,'FUCSIA','18','A1','SHC','0000106',22.00,50.00,33.00,1,1,1,NULL),(107,107,'ROJO','17','A1','PSMÑ','0000107',22.00,50.00,33.00,1,1,1,NULL),(108,108,'NEGRO','17','A1','SNWQ','0000108',22.00,50.00,33.00,1,1,1,NULL),(109,109,'ROJO','18','A1','OSNW','0000109',22.00,50.00,33.00,1,1,1,NULL),(110,110,'PERLA','17','A1','BSA','0000110',22.00,50.00,33.00,1,1,1,NULL),(111,111,'NUDE ROSA','17','A1','LAIB','0000111',22.00,50.00,33.00,1,1,1,NULL),(112,112,'BLANCO','19','A1','XKEB','0000112',22.00,50.00,33.00,1,1,1,NULL),(113,113,'ROJO','18','A1','SB','0000113',22.00,50.00,33.00,1,1,1,NULL),(114,114,'LILA','19','A1','QBR','0000114',22.00,50.00,33.00,1,1,1,NULL),(115,115,'MELON','20','A1','SGV','0000115',22.00,50.00,33.00,1,1,1,NULL),(116,116,'ROSADO','20','A1','PSM','0000116',22.00,50.00,33.00,1,1,1,NULL),(117,117,'ROJO','20','A1','FBS','0000117',22.00,50.00,33.00,1,1,1,NULL),(118,118,'ROJO','19','A1','CUM','0000118',22.00,50.00,33.00,1,1,1,NULL),(119,119,'MELON','19','A1','PÑSG','0000119',22.00,50.00,33.00,1,1,1,NULL),(120,120,'ROSADO','18','A1','EBUK','0000120',22.00,50.00,33.00,1,1,1,NULL),(121,121,'ROSADO','19','A1','DJWV','0000121',22.00,50.00,33.00,1,1,1,NULL),(122,122,'MARRON','18','A1','LPQN','0000122',22.00,50.00,33.00,1,1,1,NULL),(123,123,'LILA','20','A1','OND','0000123',22.00,50.00,33.00,1,1,1,NULL),(124,124,'ROSADO','18','A1','EVKS','0000124',22.00,50.00,33.00,1,1,1,NULL),(125,125,'NEGRO','18','A1','WBJD','0000125',22.00,50.00,33.00,1,1,1,NULL),(126,126,'BLANCO','17','A1','PSK','0000127',22.00,50.00,33.00,1,1,1,NULL),(127,127,'BEIGE','17','A1','PWKM','0000128',22.00,50.00,33.00,1,1,1,NULL),(128,128,'NEGRO','17','A1','KMS','0000129',22.00,50.00,33.00,1,1,1,NULL),(129,129,'YOGURT','17','A1','EGN','0000130',22.00,50.00,33.00,1,1,1,NULL),(130,130,'ROSADO','18','A1','WDC','0000131',22.00,50.00,33.00,1,1,1,NULL),(131,131,'FUCSIA','17','A1','SCB','0000132',22.00,50.00,33.00,1,1,1,NULL),(132,132,'ORO','19','A1','QCÑ','0000133',22.00,50.00,33.00,1,1,1,NULL),(133,133,'PLATA','17','A1','KMÑ','0000134',22.00,50.00,33.00,1,1,1,NULL),(134,134,'AZUL','17','A1','JNP','0000135',22.00,50.00,33.00,1,1,1,NULL),(135,135,'ROSADO','17','A1','FBN','0000136',22.00,50.00,33.00,1,1,1,NULL),(136,136,'BLANCO','17','A1','FCWA','0000137',22.00,50.00,33.00,1,1,1,NULL),(137,137,'PLATA','17','A1','SCG','0000138',22.00,50.00,33.00,1,1,1,NULL),(138,138,'NEGRO','20','A1','SCGS','0000139',22.00,50.00,33.00,1,1,1,NULL),(139,139,'ROSADO','17','A1','SCFR','0000140',22.00,50.00,33.00,1,1,1,NULL),(140,140,'ORO','17','A1','CFT','0000141',22.00,50.00,33.00,1,1,1,NULL),(141,141,'NEGRO','20','A1','PGE','0000142',22.00,50.00,33.00,1,1,1,NULL),(142,142,'NUDE ROSA','19','A1','CSA','0000143',22.00,50.00,33.00,1,1,1,NULL),(143,143,'VERDE','19','A1','XAZ','0000144',22.00,50.00,33.00,1,1,1,NULL),(144,144,'ANIMAL PRINCS','18','A1','DBC','0000145',22.00,50.00,33.00,1,1,1,NULL),(145,145,'NUDE','18','A1','DXA','0000146',22.00,50.00,33.00,1,1,1,NULL),(146,146,'YOGURT','19','A1','ZFVS','0000147',22.00,50.00,33.00,1,1,1,NULL),(147,147,'ROJO','17','A1','LPÑ','0000148',22.00,50.00,33.00,1,1,1,NULL),(148,148,'ROSADO METAL','17','A1','WXZA','0000149',22.00,50.00,33.00,1,1,1,NULL),(149,149,'PLATA','20','A1','PKM','0000150',22.00,50.00,33.00,1,1,1,NULL);
/*!40000 ALTER TABLE `variante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `caja_id` bigint NOT NULL,
  `cajero_id` bigint NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subtotal` decimal(12,2) NOT NULL,
  `descuento` decimal(12,2) DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL,
  `metodo_pago` varchar(50) DEFAULT NULL,
  `monto_recibido` decimal(12,2) DEFAULT NULL,
  `vuelto` decimal(12,2) DEFAULT NULL,
  `notas` text,
  PRIMARY KEY (`id`),
  KEY `idx_ventas_caja` (`caja_id`),
  KEY `idx_ventas_cajero` (`cajero_id`),
  KEY `idx_ventas_fecha` (`fecha`),
  CONSTRAINT `fk_venta_caja` FOREIGN KEY (`caja_id`) REFERENCES `cajas` (`id`),
  CONSTRAINT `fk_venta_usuario` FOREIGN KEY (`cajero_id`) REFERENCES `users` (`id`),
  CONSTRAINT `chk_metodo_pago` CHECK ((`metodo_pago` in (_utf8mb4'EFECTIVO',_utf8mb4'YAPE',_utf8mb4'TARJETA')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'calzados_pos'
--

--
-- Dumping routines for database 'calzados_pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-23 10:46:45
